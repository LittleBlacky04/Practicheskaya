from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from .utils import DataMixin
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView
from .models import Student
from .forms import *


def main(request):  # главная страница
    return render(request, "Главная/Главная.html")


def register(request):  # страница регистрации
    return render(request, "Регистрация/Регистрация.html")


def article_delete(request):
    return render(request, "")


def article_edit(request):
    return render(request, "")


def download_article(request):
    return render(request, "")


def article(request):
    return render(request, "Статья.html")


def article_add(request):
    return render(request, "")


def articles(request):
    return render(request, "Публикации/Публикации.html")


def event_delete(request):
    return render(request, "")


def event_edit(request):
    return render(request, "")


def event(request):
    return render(request, "Мероприятие/Мероприятие.html")


def add_event(request):
    return render(request, "")


def events(request):
    return render(request, "Мероприятия/Мероприятия.html")


def profile_edit(request):
    return render(request, "")


def event_speakers(request):
    return render(request, "Участники/Докладчики.html")


@login_required
def profile(request):  # страница профиля
    stud = Student.objects.get(user=request.user)
    if stud.name == "Введите ФИО":  # перевод на страницу редактирования профиля
        return HttpResponseRedirect("edit_profile")
    return render(request, "Профиль/Профиль.html")


class LoginUser(DataMixin, LoginView):  # класс для авторизации пользователя
    form_class = LoginForm
    template_name = 'Вход/Вход.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title="Вход")
        return dict(list(context.items()) + list(c_def.items()))

    def get_success_url(self):
        return reverse_lazy('profile')