from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from .utils import DataMixin
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView
from .models import Student
from .forms import *
from .models import *


def main(request):  # главная страница
    return render(request, "main.html")


def event_speakers(request, pk):
    event = get_object_or_404(Event, pk=pk)
    articles = Article.objects.filter(event=event)
    context = {
        'articles': articles,
    }
    return render(request, "event_speakers.html", context)


def download_article(request):

    return render(request, "")


def register(request):  # страница регистрации
    if request.method == 'POST':
        form = CreateUserForm(request.POST)

        if form.is_valid():
            student = Student.objects.create(
                phone_number="Телефон", organization="Введите учреждение", about="",
                user=form.save(), image="zoro.jpg"
            )  # создание профиля для пользователя
            messages.success(request, f'Вы успешно зарегистрировались. Теперь вы можете войти.')
            return HttpResponseRedirect("log_in")  # перевод на страницу входа
        else:
            messages.success(request, f'Ошибка! Проверьте корректность введенных данных')  # сообщение об ошибке
    form = CreateUserForm()
    context = {
        'form': form
    }
    return render(request, "registration.html", context)


def article_delete(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        article.delete()
        messages.success(request, f'Ваша статья успешно удалена.')
        return redirect('/articles')
    context = {
        'article': article,
    }
    return render(request, "article_delete.html", context)


def article_edit(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if request.method == 'POST':
        form = ArticleEdit(request.POST, request.FILES, instance=article)
        if form.is_valid():
            form.save()
            messages.success(request, f'Ваша статья успешно обновлена.')
            return HttpResponseRedirect("/articles")
    else:
        form = ArticleEdit(instance=article)
    context = {
        'form': form,
    }
    return render(request, "article_edit.html", context)


def article(request, pk):  # страница информации о статье
    article = get_object_or_404(Article, pk=pk)
    author = get_object_or_404(Article_User, article_id=pk)
    user = get_object_or_404(User, username=author.user_id)
    context = {
        'article': article,
        'author': user
    }
    return render(request, "article.html", context)


def take_part(request, pk):
    event = get_object_or_404(Event, pk=pk)
    articles = Article.objects.filter(user=request.user)
    context = {
        'event': event,
        'articles': articles,
    }
    return render(request, "take_part.html", context)


def choose_article(request, pk, art):
    event = get_object_or_404(Event, pk=pk)
    article = get_object_or_404(Article, pk=art)
    if request.method == 'POST':
        con = Event_Article.objects.filter(event_id=pk, article_id=art)
        if con.exists():
            messages.success(request, f'Эта статья уже зарегистрированна. Выберите другую статью')
            return redirect('/events/event/' + str(pk) + '/take_part')
        con = Event_Article.objects.create(article_id=article, event_id=event)
        messages.success(request, f'Ваша статья успешно зарегистрирована. Вас будут ожидать на мерорприятии')
        return redirect('/events/event/' + str(pk))
    context = {
        'event': event,
        'article': article,
    }
    return render(request, "choose_article.html", context)


def article_add(request):
    if request.method == 'POST':
        form = ArticleEdit(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save(commit=False)
            user = User.objects.filter(username=request.user)
            obj.save()
            obj.user.set(user)
            obj.save()
            messages.success(request, f'Ваша статья успешно добавлена.')
            return redirect('/articles')
        else:
            messages.success(request, f'Ваша статья не была добавлена. Проверьте корректность введенных данных')
    else:
        form = ArticleEdit(instance=request.user)
    context = {
        'form': form,
    }
    return render(request, "article_add.html", context)


@login_required
def articles(request):
    article = Article.objects.filter(user=request.user)
    context = {
        'articles': article,
    }
    return render(request, "select_article.html", context)


def event_delete(request, pk):
    event = get_object_or_404(Event, pk=pk)
    if request.method == 'POST':
        event.delete()
        messages.success(request, f'Ваше мероприятие успешно удалено')
        return redirect('/events')
    context = {
        'event': event,
    }
    return render(request, "event_delete.html", context)


def event_edit(request, pk):
    event = get_object_or_404(Event, pk=pk)
    if request.method == 'POST':
        form = EventEdit(request.POST, request.FILES, instance=event)
        if form.is_valid():
            form.save()
            messages.success(request, f'Вашe мероприятие успешно обновлена.')
            return HttpResponseRedirect("/events")
    else:
        form = EventEdit(instance=event)
    context = {
        'form': form,
    }
    return render(request, "event_edit.html", context)


def event(request, pk):  # страница информации о конференции
    event = get_object_or_404(Event, pk=pk)
    orgs = User.objects.filter(event_user__event_id_id=pk, event_user__is_org="True")
    try:
        org = Event_User.objects.get(event_id=pk, user_id=request.user)
        context = {
            'event': event,
            'orgs': orgs,
            'org': org,
        }
    except Exception:
        context = {
            'event': event,
            'orgs': orgs,
        }
    return render(request, "conference.html", context)


def add_event(request):
    if request.method == 'POST':
        form = EventEdit(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save(commit=False)
            user = User.objects.filter(username=request.user)
            obj.save()
            obj.user.set(user, through_defaults={"is_org": True})
            obj.save()
            messages.success(request, f'Ваше мероприятие успешно добавлено.')
            return redirect('/events')
        else:
            messages.success(request, f'Ваше мероприятие не было добавлено. Проверьте корректность введенных данных')
    else:
        form = EventEdit(instance=request.user)
    context = {
        'form': form,
    }
    return render(request, "add_event.html", context)


def events(request):
    events = Event.objects.all()
    context = {
        'events': events,
    }
    return render(request, "select_conference.html", context)


def my_events(request):
    events = Event.objects.filter(user=request.user)
    context = {
        'events': events
    }
    return render(request, "select_conference.html", context)


def profile_edit(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = StudentUpdateForm(request.POST,
                                   request.FILES,
                                   instance=request.user.student)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            messages.success(request, f'Ваш профиль успешно обновлен.')  # сообщение об успехе
            return redirect('profile')  # перевод на страницу профиля
    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = StudentUpdateForm(instance=request.user.student)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }
    return render(request, "edit_profile.html", context)


@login_required
def profile(request):  # страница профиля
    stud = Student.objects.get(user=request.user)
    if stud.phone_number == "Телефон":  # перевод на страницу редактирования профиля
        return HttpResponseRedirect("/profile/edit")
    return render(request, "profile.html")


class LoginUser(DataMixin, LoginView):  # класс для авторизации пользователя
    form_class = LoginForm
    template_name = 'log_in.html'

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        c_def = self.get_user_context(title="Вход")
        return dict(list(context.items()) + list(c_def.items()))

    def get_success_url(self):
        return reverse_lazy('profile')
