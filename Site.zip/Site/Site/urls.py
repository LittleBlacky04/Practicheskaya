"""Site URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path
from Articles import views as user_views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),  # админка
    path('main', user_views.main, name='main'),  # главная
    path('log_in', user_views.LoginView.as_view(template_name='Вход/Вход.html'), name='log_in'),  # вход
    re_path('log_out', auth_views.LogoutView.as_view(template_name=''), name='log_out'),  # выход
    path('register', user_views.register, name='log_in'),  # регистрация
    path('articles/article/<int:pk>/delete', user_views.article_delete, name='article'),  # удаление статьи
    path('articles/article/<int:pk>/edit', user_views.article_edit, name='article_edit'),  # редактирование статьи
    path('articles/article/<int:pk>/download', user_views.download_article, name='article_edit'),  # загрузить статью
    path('articles/article/<int:pk>/', user_views.article, name='article'),  # страница статьи
    path('articles/add', user_views.article_add, name='article_add'),  # добавить статью
    path('articles', user_views.articles, name='articles'),  # статьи
    path('events/event/<int:pk>/delete', user_views.event_delete, name='event_delete'),  # удаление конференции
    path('events/event/<int:pk>/edit', user_views.event_edit, name='event_edit'),  # редактирование конференции
    path('events/event/<int:pk>/speakers', user_views.event_speakers, name='event_speakers'),  # список участников
    path('events/event/<int:pk>/', user_views.event, name='event'),  # страница конференции
    path('events/add', user_views.add_event, name='add_event'),  # добавить конференцию
    path('events', user_views.events, name='events'),  # конференции
    path('profile/edit', user_views.profile_edit, name='profile'),  # редактирование профиля
    path('profile', user_views.profile, name='profile'),  # профиль
]
