from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import *
from django.core.exceptions import ValidationError
from django.forms import ModelForm
from django.forms.fields import EmailField
from django.forms.forms import Form
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from .models import Student

class LoginForm(AuthenticationForm):  # форма авторизации
    username = forms.CharField(label='Логин', widget=forms.TextInput(attrs={
        "class": "form-input u-form-group u-form-name u-label-top"
    }))
    password = forms.CharField(label='Пароль', widget=forms.PasswordInput(attrs={
        "class": "form-input u-form-group u-label-top"
    }))